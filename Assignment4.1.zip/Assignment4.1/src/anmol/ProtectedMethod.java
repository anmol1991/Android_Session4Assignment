package anmol;

public class ProtectedMethod {
		
		int val = 10;
		
		public ProtectedMethod()
		{
			System.out.println("Constructor of ProtectedMethod class called\n");
		}
		protected int returnVal()
		{
			return val;
		}
	

}

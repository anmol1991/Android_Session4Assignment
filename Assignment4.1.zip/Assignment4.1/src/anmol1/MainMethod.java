package anmol1;
import anmol.*;

public class MainMethod   {
	
		public static void main(String s[]){
			SubClass ss = new SubClass();
			ss.displayReturnVal();
			
		}
}

class SubClass extends ProtectedMethod{
	
	SubClass()
	{
		System.out.println("Constructor of SubcLass called");
	}
	void displayReturnVal()
	{
		System.out.println("Return value = " + super.returnVal());
	}
}
